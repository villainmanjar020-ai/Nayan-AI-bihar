NAYAN AI – BIHAR starter demo
Open index.html in a browser to preview.
This is a front-end demo with sample local replies. It is NOT connected to a live AI model yet. Real AI requires a secure backend and an AI provider. Never place a secret API key in browser code.
Voice input depends on browser support. For Android installation, host the files on HTTPS, open the site in Chrome, then choose Install app or Add to Home screen if offered.